fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Freska'
description 'Advanced Anti-Cheat System'
version '1.0.0'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/*.lua',
}
