Config = {}

Config.Framework = 'qb-core' -- 'qb-core' / 'qbx_core' / 'es_extended'

Config.Webhook = ''

Config.BlacklistedWeapons = {
    'WEAPON_RAILGUN',
    'WEAPON_MINIGUN',
    'WEAPON_RPG',
    'WEAPON_HOMINGLAUNCHER',
}

Config.BlacklistedModels = { -- Vehicles
    [`rhino`] = true,
    [`lazer`] = true,
    [`hydra`] = true
}

Config.InvincibilityCheck = true
Config.SpectateCheck = true
Config.WeaponCheck = true
Config.NoClipCheck = true
Config.SpawnCheck = true

Config.BanOnDetection = true
