local function IsInvincible(ped)
    return GetPlayerInvincible(PlayerId())
end

local function IsSpectating()
    return NetworkIsInSpectatorMode()
end

local function HasBlacklistedWeapon(ped)
    for _, weapon in pairs(Config.BlacklistedWeapons) do
        if HasPedGotWeapon(ped, GetHashKey(weapon), false) then
            return weapon
        end
    end
    return false
end

CreateThread(function()
    local lastCoords = GetEntityCoords(PlayerPedId())
    while true do
        Wait(3000)
        if Config.NoClipCheck then
            local ped = PlayerPedId()
            if DoesEntityExist(ped) then
                local currentCoords = GetEntityCoords(ped)
                if #(currentCoords - lastCoords) > 100.0 then
                    TriggerServerEvent('Freska_AC:Flag', 'NoClip / Teleport Detected')
                end
                lastCoords = currentCoords
            end
        end
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        if not DoesEntityExist(ped) then Wait(1000) goto continue end

        if Config.InvincibilityCheck and GetPlayerInvincible(PlayerId()) then
            TriggerServerEvent('Freska_AC:Flag', 'Godmode Detected')
        end

        if Config.SpectateCheck and NetworkIsInSpectatorMode() then
            TriggerServerEvent('Freska_AC:Flag', 'Spectate Mode Detected')
        end

        if Config.WeaponCheck then
            local weapon = HasBlacklistedWeapon(ped)
            if weapon then
                TriggerServerEvent('Freska_AC:Flag', 'Blacklisted Weapon: ' .. weapon)
                RemoveWeaponFromPed(ped, GetHashKey(weapon))
            end
        end

        ::continue::
        Wait(5000)
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        RestorePlayerStamina(PlayerId(), 0.0)
    end
end)
