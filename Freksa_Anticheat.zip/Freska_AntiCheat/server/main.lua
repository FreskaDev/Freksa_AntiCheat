--[[
    Freska Anti-Cheat Unified Server Script
    Author: Freska
    Description: Advanced Anti-Cheat System with kick on detection
]]

-- UTILS --

local function GetPlayerIdentifiersInfo(src)
    local identifiers = {}
    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local id = GetPlayerIdentifier(src, i)
        if id:match("license:") then identifiers.license = id end
        if id:match("steam:") then identifiers.steam = id end
        if id:match("discord:") then identifiers.discord = id:gsub("discord:", "") end
    end
    return identifiers
end

local function SendToDiscord(title, description)
    if not Config.Webhook or Config.Webhook == "" then return end
    local payload = json.encode({
        username = "Freska Anti-Cheat",
        embeds = {{
            title = title,
            description = description,
            color = 16711680, -- Red
            footer = { text = "Freska AC • " .. os.date("%Y-%m-%d %H:%M:%S") }
        }}
    })
    PerformHttpRequest(Config.Webhook, function() end, "POST", payload, {
        ["Content-Type"] = "application/json"
    })
end

local function KickPlayer(src, reason)
    if not src or src <= 0 then return end
    DropPlayer(src, "[Anti-Cheat] You have been kicked. Reason: " .. tostring(reason))
    print(("[ANTI-CHEAT] Player %d kicked for reason: %s"):format(src, reason))
end

local function HandleFlaggedPlayer(src, reason)
    if not src or src <= 0 then return end

    local name = GetPlayerName(src) or "Unknown"
    local ids = GetPlayerIdentifiersInfo(src)
    local license = ids.license or "N/A"
    local steam = ids.steam or "N/A"
    local discord = ids.discord or "N/A"
    local time = os.date("%Y-%m-%d %H:%M:%S")

    local logMsg = string.format(
        "[%s] Player: %s | License: %s | Steam: %s | Discord: %s - Reason: %s",
        time, name, license, steam, discord, reason
    )

    print("^1[ANTI-CHEAT]^7 " .. logMsg)
    SendToDiscord("🚨 Anti-Cheat Detection", logMsg)
    KickPlayer(src, reason)
end

-- EVENTS --

RegisterServerEvent('Freska_AC:Flag')
AddEventHandler('Freska_AC:Flag', function(reason)
    local src = source
    HandleFlaggedPlayer(src, reason)
end)

AddEventHandler('entityCreating', function(entity)
    if not DoesEntityExist(entity) then return end

    local model = GetEntityModel(entity)
    local owner = NetworkGetEntityOwner(entity)

    if Config.BlacklistedModels[model] and owner and owner > 0 then
        CancelEvent()
        HandleFlaggedPlayer(owner, "Blacklisted Model Spawned: " .. model)
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    local currentResource = GetCurrentResourceName()
    if resourceName == currentResource then return end

    for _, playerId in ipairs(GetPlayers()) do
        DropPlayer(playerId, ("[Anti-Cheat] Resource Stop Attempt Detected: %s"):format(resourceName))
    end
end)
